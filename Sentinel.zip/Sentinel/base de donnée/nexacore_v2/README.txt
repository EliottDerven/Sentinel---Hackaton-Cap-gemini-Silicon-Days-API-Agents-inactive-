NEXACORE TECHNOLOGIES — BASE DE DONNÉES DE TEST SENTINELS v2
=============================================================
Version : 2.0 — Janvier 2026
Données entièrement fictives — usage démonstration uniquement

NOUVEAUTÉS v2 vs v1 :
+ Metadata/meta/metadata_all_files.json         — métadonnées structurées des 22 fichiers
+ Metadata/logs_individuels/logs_par_fichier.json — logs d'accès par fichier
+ Metadata/historique_versions/historique_versions.json — historique modifications
+ Metadata/ayants_droit/matrice_acces.json      — droits explicites + failles IAM
+ Metadata/canaux_partage/registre_partages.json — email/Teams/téléchargements + alertes DLP

SCÉNARIO INCIDENT : Tom Michel (NXC-025) suspecté d'exfiltration 09-13/01/2026
5 fichiers exfiltrés — IPs : NordVPN NL + VPS OVH FR
Cause racine : faille IAM groupe R&D droits trop larges (FAILLE-IAM-001)
